# Mariam Hamad - 1200837
# Leena Affouri - 1200335
import math
from math import log2

from flask import Flask, render_template, request, jsonify

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def first():
    results = {
        'sampling_frequency': '',
        'quantization_levels': '',
        'source_encoder_rate': '',
        'channel_encoder_rate': '',
        'interleaver_rate': ''
    }

    if request.method == 'POST':
        try:
            # Retrieve bandwidth and its unit from the form
            bandwidth = int(request.form.get('bandwidth', 0))
            bandwidth_unit = request.form.get('unit', 'Hz')

            # Convert bandwidth to Hz if it's in kHz
            if bandwidth_unit == 'kHz':
                bandwidth *= 1000  # Convert kHz to Hz

            bits = int(request.form.get('bits', 0))
            compression = float(request.form.get('compression', 1.0))
            encoder_rate = float(request.form.get('encoder_rate', 1.0))
            interleaver_bits = int(request.form.get('interleaver_bits', 0))

            # Perform calculations
            sampling_frequency = 2 * bandwidth
            quantization_levels = 2 ** bits
            input_source_encoder = sampling_frequency * bits
            source_encoder_rate = input_source_encoder * compression
            channel_encoder_rate = source_encoder_rate / encoder_rate
            interleaver_rate = channel_encoder_rate

            results.update({
                'sampling_frequency': f"{sampling_frequency}",
                'quantization_levels': f"{quantization_levels}",
                'input_source_encoder': f"{input_source_encoder}",
                'source_encoder_rate': f"{source_encoder_rate}",
                'channel_encoder_rate': f"{channel_encoder_rate}",
                'interleaver_rate': f"{interleaver_rate}"
            })
        except ValueError:
            # If there is an error in input conversion, you might want to handle it
            pass

    return render_template('First.html', results=results, active_page='First')


@app.route('/resource-elements', methods=['GET', 'POST'])
def resource_elements():
    results = {
        'bitsPerResourceElement': '',
        'bitsPerOfdmSymbol': '',
        'bitsPerOfdmResourceBlock': '',
        'transmissionRate': ''
    }
    errors = {}  # Dictionary to store error messages

    if request.method == 'POST':
        try:
            bandwidth_unit = request.form.get('bandwidthUnit', 'Hz')
            bandwidth = float(request.form.get('bandwidth', 0))
            if bandwidth_unit == 'kHz':
                bandwidth *= 1000

            spacing_unit = request.form.get('spacingUnit', 'Hz')
            spacing = float(request.form.get('spacing', 0))
            if spacing_unit == 'kHz':
                spacing *= 1000

            ofdmSymbols = int(request.form.get('ofdm_symbols', 0))

            duration_unit = request.form.get('durationUnit', 'sec')
            resourceBlockDuration = float(request.form.get('resource_block_duration', 0))
            if duration_unit == 'msec':
                resourceBlockDuration *= 1e-3

            modulationVal = int(request.form.get('modulation_val', 0))
            if modulationVal <= 0:
                raise ValueError("Modulation level must be greater than zero for log calculation.")

            numberOfParallelRb = int(request.form.get('parallel_blocks', 0))

            subcarriers = bandwidth / spacing
            bitsPerResourceElement = math.log2(modulationVal)
            bitsPerOfdmSymbol = bitsPerResourceElement * subcarriers
            bitsPerOfdmResourceBlock = bitsPerOfdmSymbol * ofdmSymbols
            transmissionRate = (numberOfParallelRb * bitsPerOfdmResourceBlock) / resourceBlockDuration

            results['bitsPerResourceElement'] = f"{bitsPerResourceElement:.2f} bits"
            results['bitsPerOfdmSymbol'] = f"{bitsPerOfdmSymbol:.2f} bits"
            results['bitsPerOfdmResourceBlock'] = f"{bitsPerOfdmResourceBlock:.2f} bits"
            results['transmissionRate'] = f"{transmissionRate:.2f} bps"

        except ValueError as e:
            errors['modulation_val'] = "Modulation level must be greater than zero for log calculation."

    return render_template('resource_elements.html', results=results, errors=errors, active_page='resource-elements')


@app.route('/power-transmission', methods=['GET', 'POST'])
def power_transmission():
    results = {
        'EbN0': ' ',
        'Pr': ' ',
        'Pt': ' ',  # Power transmitted initialized as not available
        'Pr_no_unit': ' ',
        'Pt_no_unit': ' ',
        'Pr_dbm': ' ',
        'Pt_dbm': ' ',
        'error': ''  # To store potential error messages
    }

    # Lookup tables for BER to E_b/N_0 (dB) should be defined within the function to ensure they are accessible
    ber_to_ebn0 = {
        'BPSK/QPSK': {1e-8: 14.5, 1e-7: 13.5, 1e-6: 12.5, 1e-5: 11.5, 1e-4: 10.5, 1e-3: 9.5, 1e-2: 8.5, 1e-1: 7.5,
                      1e0: 6.5},
        '8-PSK': {1e-8: 16, 1e-7: 15, 1e-6: 14, 1e-5: 13, 1e-4: 12, 1e-3: 11, 1e-2: 10, 1e-1: 9, 1e0: 8},
        '16-PSK': {1e-8: 18, 1e-7: 17, 1e-6: 16, 1e-5: 15, 1e-4: 14, 1e-3: 13, 1e-2: 12, 1e-1: 11, 1e0: 10}
    }
    modulation_schemes = {
        '1': 'BPSK/QPSK',
        '2': '8-PSK',
        '3': '16-PSK'
    }
    if request.method == 'POST':
        try:

            def convert_to_dB(value, unit):
                try:
                    if value == '':
                        return 0  # Handle empty inputs by returning 0 dB or no change
                    value = float(value)
                    if unit == 'dBm':
                        return value - 30  # Convert dBm to dB
                    elif unit == 'None':
                        if value <= 0:
                            raise ValueError("Value must be positive for logarithmic conversion.")
                        return 10 * math.log10(value)  # Handle 'No Unit' as 0 dB for neutrality in calculations
                    elif unit == 'dB':
                        return value
                    elif unit == 'Hz':
                        return value  # Frequency in Hz doesn't convert to dB
                    elif unit == 'kHz':
                        return value * 1000  # Convert kHz to Hz
                    elif unit == 'MHz':
                        return value * 1000000  # Convert MHz to Hz
                    else:
                        raise ValueError(f"Unsupported unit {unit}")
                except ValueError as e:
                    results['error'] = str(e)
                    return None

            path_loss = convert_to_dB(request.form['pathLoss'], request.form['pathLossUnit'])
            frequency = convert_to_dB(request.form['frequency'], request.form['frequencyUnit'])
            transmit_antenna_gain = convert_to_dB(request.form['transmitAntennaGain'],
                                                  request.form['transmitAntennaGainUnit'])
            receive_antenna_gain = convert_to_dB(request.form['receiveAntennaGain'],
                                                 request.form['receiveAntennaGainUnit'])
            antenna_feed_line_loss = convert_to_dB(request.form['antennaFeedLineLoss'],
                                                   request.form['antennaFeedLineLossUnit'])
            other_losses = convert_to_dB(request.form['otherLosses'], request.form['otherLossesUnit'])
            fade_margin = convert_to_dB(request.form['fadeMargin'], request.form['fadeMarginUnit'])
            receiver_amplifier_gain = convert_to_dB(request.form['receiverAmplifierGain'],
                                                    request.form['receiverAmplifierGainUnit'])
            noise_figure = convert_to_dB(request.form['noiseFigure'], request.form['noiseFigureUnit'])
            data_rate = float(request.form.get('dataRate', 0))  # Directly use as bps
            noise_temp = float(request.form['noiseTemp'])
            link_margin = convert_to_dB(request.form['linkMargin'], request.form['linkMarginUnit'])

            bit_error_rate_input = request.form['bitErrorRate'].replace('^', '**')
            bit_error_rate = eval(bit_error_rate_input)

            modulation = request.form['modulation']
            modulation_scheme = modulation_schemes[modulation]
            results['EbN0'] = ber_to_ebn0[modulation_scheme][bit_error_rate]
            noise_temp = 10 * math.log10(noise_temp)
            data_rate = 10 * math.log10(data_rate)
            k = -228.6

            # Printing values to debug
            print(f"path_loss: {path_loss}, frequency: {frequency}, transmit_antenna_gain: {transmit_antenna_gain}")
            print(
                f"receive_antenna_gain: {receive_antenna_gain}, data_rate: {data_rate}, antenna_feed_line_loss: {antenna_feed_line_loss}")
            print(
                f"other_losses: {other_losses}, fade_margin: {fade_margin}, receiver_amplifier_gain: {receiver_amplifier_gain}")
            print(
                f"noise_figure: {noise_figure}, noise_temp: {noise_temp}, link_margin: {link_margin}, EbN0: {results['EbN0']}")

            pr = link_margin + k + noise_temp + noise_figure + data_rate + results['EbN0']
            results['Pr'] = f"{pr:.4f} dB"

            pt = pr + path_loss + antenna_feed_line_loss + other_losses + fade_margin - transmit_antenna_gain - receive_antenna_gain - receiver_amplifier_gain
            results['Pt'] = f"{pt:.4f} dB"

            pr_no_unit = 10 ** (pr / 10)
            pt_no_unit = 10 ** (pt / 10)
            results['Pr_no_unit'] = f"{pr_no_unit:.4e}"
            results['Pt_no_unit'] = f"{pt_no_unit:.4e}"

            # Convert Pr and Pt from dBm to dB
            pr_dbm = pr + 30  # Assuming the given Pr is already in dBm
            pt_dbm = pt + 30
            results['Pr_dbm'] = f"{pr_dbm:.4f} dBm"
            results['Pt_dbm'] = f"{pt_dbm:.4f} dBm"
            if results['error']:
                raise ValueError(results['error'])

        except ValueError as e:
            results['error'] = f"Error converting input values: {str(e)}"
        except KeyError as e:
            results['error'] = f"Missing input or incorrect values: {str(e)}"

    return render_template('power_transmission.html', results=results, active_page='power-transmission')


@app.route('/multiple-access', methods=['GET', 'POST'])
def multiple_access():
    results = {}  # Initialize results as an empty dictionary
    if request.method == 'POST':
        # Retrieve form data and unit conversions
        bandWidth = float(request.form.get('bandWidth', 0))
        bandWidthUnit = request.form.get('bandWidthUnit', 'Kbps')  # Get the bandwidth unit
        maxSignalProb = float(request.form.get('maxSignalProb', 0))
        timeUnit = request.form.get('timeUnit', 'sec')  # Get the time unit
        frameSize = float(request.form.get('frameSize', 0))
        frameSizeUnit = request.form.get('frameSizeUnit', 'Bytes')  # Get the frame size unit
        frameRate = float(request.form.get('frameRate', 0))
        frameRateUnit = request.form.get('frameRateUnit', 'fps')  # Get the frame rate unit
        calculationType = request.form.get('type', '')

        # Convert bandwidth based on selected unit
        if bandWidthUnit == 'Mbps':
            bandWidth *= 1000000
        elif bandWidthUnit == 'Kbps':
            bandWidth *= 1000
        elif bandWidthUnit == 'Gbps':
            bandWidth *= 1000000000

        # Convert max signal propagation time based on selected unit
        if timeUnit == 'msec':
            maxSignalProb /= 1000
        elif timeUnit == 'microsec':
            maxSignalProb /= 1000000

        # Convert frame size based on selected unit
        if frameSizeUnit == 'KB':
            frameSize *= 1000  # Convert KB to bytes and then to bits
        elif frameSizeUnit == 'MB':
            frameSize *= 1000000  # Convert MB to bytes and then to bits

        # Convert frame rate based on selected unit
        if frameRateUnit == 'fpm':
            frameRate /= 60
        elif frameRateUnit == 'kfps':
            frameRate *= 1000

        # Compute throughput based on the type selected
        T = frameSize / bandWidth
        alpha = maxSignalProb / T
        G = frameRate * T
        throughput = 0

        if calculationType == "Throughput of Pure ALOHA":
            throughput = G * T * math.exp(-2 * G * T)
        elif calculationType == "Throughput of slotted ALOHA":
            throughput = G * T * math.exp(-G * T)
        elif calculationType == "Throughput unslotted nonpersistent CSMA":
            throughput = (G * math.exp(-2 * alpha * T)) / (G * (1 + 2 * alpha) + math.exp(-alpha * G))
        elif calculationType == "Throughput slotted nonpersistent CSMA":
            throughput = (alpha * G * math.exp(-2 * alpha * T)) / (G * (1 - math.exp(-2 * alpha * G) + alpha))
        elif calculationType == "Throughput unslotted 1-persistent CSMA":
            throughput = (G * (1 + G + alpha * G * (1 + G + alpha * G / 2)) * math.exp(-G * (1 + 2 * alpha))) / \
                         (G * (1 + 2 * alpha) - (1 - math.exp(-2 * alpha * G)) + (1 + alpha * G) * math.exp(
                             -G * (1 + alpha)))

        elif calculationType == "Throughput slotted 1-persistent CSMA":
            throughput = (G * (1 + alpha - math.exp(-alpha * G)) * math.exp(-G * (1 + alpha))) / \
                         ((1 + alpha) * (1 - math.exp(-alpha * G)) + alpha * math.exp(-G * (1 + alpha)))
        else:
            throughput = "Type undefined."

        # Convert to percentage
        results['throughput'] = 100 * throughput

    # Always return a response for both GET and POST
    return render_template('multiple_access.html', active_page='multiple-access', results=results)


@app.route('/cellular-design', methods=['GET', 'POST'])
def cellular_design():
    def load_erlang_data(filename):
        data = []
        with open(filename, 'r') as file:
            headers = file.readline().strip().split(',')
            for line in file:
                values = line.strip().split(',')
                data.append(dict(zip(headers, values)))
        print("Erlang data loaded:", data)
        return data

    def erlang_b(A, N):
        invB = 1.0
        for i in range(1, N + 1):
            invB = 1 + invB * (i / A)
        return 1.0 / invB

    def erlang_c(A, N):
        """ Calculate the Erlang C formula used to estimate queuing probability. """
        sum_series = 0
        N = int(N)  # Ensure N is an integer for range function
        for i in range(N):
            sum_series += pow(A, i) / math.factorial(i)
        pb = (pow(A, N) / math.factorial(N)) * (N / (N - A)) / (
                    sum_series + (pow(A, N) / math.factorial(N)) * (N / (N - A)))
        return pb

    def find_traffic_intensity_c(blocking_probability, traffic_intensity, tolerance=1e-6):
        """ Calculate the traffic intensity that leads to a specific blocking probability using the Erlang C formula. """

        low = 1
        high = 100  # Starting with a reasonable high value, can be adjusted as needed
        mid = 0

        while high - low > tolerance:
            mid = (low + high) // 2
            current_blocking_probability = erlang_c(traffic_intensity,mid)

            if current_blocking_probability > blocking_probability:
                low = mid + 1
            else:
                high = mid

        return (low + high) // 2



    def find_number_of_channels(blocking_probability, traffic_intensity, tolerance=1e-6):
        low = 1
        high = 100  # Starting with a reasonable high value, can be adjusted as needed
        mid = 0

        while high - low > tolerance:
            mid = (low + high) // 2
            current_blocking_probability = erlang_b(traffic_intensity, mid)

            if current_blocking_probability > blocking_probability:
                low = mid + 1
            else:
                high = mid

        return (low + high) // 2

    def find_closest_value(data, column_name, target_value):
        closest_value = None
        print(f"Looking for the closest value in column: {column_name}")
        for row in data:
            value = float(row[column_name])
            if value >= target_value:
                closest_value = row['No_of_Channels']
                break
        return closest_value

    def get_column_name(gosProbability):
        columns = ['0.1%', '0.2%', '0.5%', '1%', '1.2%', '1.5%', '2%', '3%', '5%', '7%', '10%', '15%', '20%', '30%']
        for col in columns:
            if float(col.strip('%')) / 100 >= gosProbability:
                return col
        return columns[-1]  # Return the highest GOS column if none matches exactly

    results = {}  # Initialize results as an empty dictionary
    if request.method == 'POST':
        try:
            # Retrieve form data and handle unit conversions
            numChannels = int(request.form.get('numChannels', 0))
            cityArea = float(request.form.get('cityArea', 0))
            areaUnit = request.form.get('areaUnit', 'm^2')
            numUsers = int(request.form.get('numUsers', 0))
            usersUnit = request.form.get('usersUnit', 'thousand')
            callsPerDay = float(request.form.get('callsPerDay', 0))
            callsUnit = request.form.get('callsUnit', 'per day')
            callDuration = float(request.form.get('callDuration', 0))
            durationUnit = request.form.get('durationUnit', 'min')
            gosProbability = float(request.form.get('gosProbability', 0))
            minimumSIR = float(request.form.get('minimumSIR', 0))
            sirUnit = request.form.get('sirUnit', 'dB')
            refDistance = float(request.form.get('refDistance', 0))
            distanceUnit = request.form.get('distanceUnit', 'm')
            probD0 = float(request.form.get('probD0', 0))
            probUnit = request.form.get('probUnit', 'dB')
            pathLossExponent = float(request.form.get('pathLossExponent', 0))
            receiverSensitivity = float(request.form.get('receiverSensitivity', 0))
            sensitivityUnit = request.form.get('sensitivityUnit', 'watt')
            coChannelCells = int(request.form.get('coChannelCells', 0))
            erlangType = request.form.get('erlangType', 'ErlangB')

            # Load appropriate Erlang table data
            if erlangType == 'ErlangB':
                erlang_data = load_erlang_data('data/erlangBTable.txt')
            elif erlangType == 'ErlangC':
                erlang_data = load_erlang_data('data/erlangCTable.txt')
            else:
                return jsonify({"error": "Invalid Erlang type"}), 400

            # Convert city area to square meters if necessary
            if areaUnit == 'km^2':
                cityArea *= 1e6  # Convert square kilometers to square meters

            # Convert number of users based on unit
            if usersUnit == 'thousand':
                numUsers *= 1e3
            elif usersUnit == 'hundred thousand':
                numUsers *= 1e5
            elif usersUnit == 'million':
                numUsers *= 1e6

            # Convert the call duration to minutes based on the unit
            if durationUnit == 'sec':
                callDuration = callDuration / 60  # Convert seconds to minutes
            elif durationUnit == 'min':
                callDuration = callDuration  # Already in minutes
            elif durationUnit == 'hour':
                callDuration = callDuration * 60  # Convert hours to minutes

            # Convert the number of calls to per day based on the unit
            if callsUnit == 'per sec':
                callsPerDay = callsPerDay * 60 * 60 * 24  # Convert per second to per day
            elif callsUnit == 'per min':
                callsPerDay = callsPerDay * 60 * 24  # Convert per minute to per day
            elif callsUnit == 'per hour':
                callsPerDay = callsPerDay * 24  # Convert per hour to per day
            elif callsUnit == 'per day':
                callsPerDay = callsPerDay  # Already per day

            # Handle unit conversion for SIR
            if sirUnit == 'dB':
                # Convert dB to a linear scale ratio if needed
                minimumSIR = 10 ** (minimumSIR / 10)  # This makes it unitless but as a ratio
            elif sirUnit == 'dBm':
                # Convert dBm to Watts, then to a unitless form by considering 1 mW as base
                minimumSIR = 10 ** ((minimumSIR - 30) / 10)  # Subtract 30 to convert dBm to dBW, then to linear scale
            elif sirUnit == 'no unit':
                minimumSIR = minimumSIR  # Already unitless

            # Convert the reference distance to meters based on the unit
            if distanceUnit == 'cm':
                refDistance = refDistance / 100  # Convert centimeters to meters
            elif distanceUnit == 'm':
                refDistance = refDistance  # Already in meters
            elif distanceUnit == 'km':
                refDistance = refDistance * 1000  # Convert kilometers to meters

            # Convert the probability to a unitless form based on the unit
            if probUnit == 'dB':
                # Convert dB to a linear scale power ratio
                probD0 = 10 ** (probD0 / 10)
            elif probUnit == 'dBm':
                # Convert dBm to Watts, then to a linear scale ratio (unitless in terms of power)
                probD0 = 10 ** ((probD0 - 30) / 10)
            elif probUnit == 'no unit':
                probD0 = probD0  # Assume it's already in a linear scale if no unit

            # Convert the receiver sensitivity to watts based on the unit
            if sensitivityUnit == 'kW':
                receiverSensitivity = receiverSensitivity * 1000  # Convert kilowatts to watts
            elif sensitivityUnit == 'watt':
                receiverSensitivity = receiverSensitivity  # Already in watts
            elif sensitivityUnit == 'μW':
                receiverSensitivity = receiverSensitivity / 1e6  # Convert microwatts to watts

            # Compute the required outputs
            # 1. Maximum Distance
            maxDistance = refDistance * (probD0 / receiverSensitivity) ** (1 / pathLossExponent)
            print(f"Maximum Distance: {maxDistance}")

            # 2. Cell Size
            cellSize = (3 * math.sqrt(3) / 2) * (maxDistance ** 2)
            print(f"Cell Size: {cellSize}")

            # 3. Number of Cells
            numCells = cityArea / cellSize
            print(f"Number of Cells: {numCells}")

            # 4. System Traffic
            systemTraffic = numUsers * callsPerDay * callDuration / (24 * 60)
            print(f"System Traffic: {systemTraffic}")

            # 5. Traffic per Cell
            trafficPerCell = systemTraffic / numCells
            print(f"Traffic per Cell: {trafficPerCell}")

            # 6. Cells per Cluster
            cellsPerCluster = (minimumSIR * coChannelCells) ** (2 / pathLossExponent) / (3)
            print(f"minimumSIR: {minimumSIR}")
            print(f"coChannelCells: {coChannelCells}")
            print(f"pathLossExponent: {pathLossExponent}")
            print(f"Cells per Cluster: {cellsPerCluster}")

            # 7. Find the required carriers for the given GOS and traffic per cell
            column_name = get_column_name(gosProbability)
            print(f"Selected column for GOS {gosProbability}: {column_name}")
            closest_traffic_value = find_closest_value(erlang_data, column_name, trafficPerCell)

            if closest_traffic_value is None:
                print(f"No suitable traffic value found for GOS {gosProbability} and traffic per cell {trafficPerCell}")
                return jsonify({"error": "No suitable traffic value found for the given GOS"}), 400

            min_carriers_needed = int(closest_traffic_value)
            print(f"Minimum Carriers Needed: {min_carriers_needed}")

            if erlangType == 'ErlangB':
                required_channels = find_number_of_channels(gosProbability, trafficPerCell)
            elif erlangType == 'ErlangC':
                required_channels = find_traffic_intensity_c(gosProbability, trafficPerCell)

            # Find the number of channels using Erlang B formula
            # = find_number_of_channels(gosProbability, trafficPerCell)

            print(f"Required Channels: {required_channels}")

            results = {
                'maxDistance': maxDistance,
                'cellSize': cellSize,
                'numCells': numCells,
                'systemTraffic': systemTraffic,
                'trafficPerCell': trafficPerCell,
                'cellsPerCluster': cellsPerCluster,
                'minCarriers': required_channels / numChannels  # Add required channels to results
            }

        except Exception as e:
            print(f"Error: {e}")
            return jsonify({"error": str(e)}), 400

    return render_template('cellular_design.html', results=results, active_page='cellular-design')


if __name__ == '__main__':
    app.run(debug=True)
